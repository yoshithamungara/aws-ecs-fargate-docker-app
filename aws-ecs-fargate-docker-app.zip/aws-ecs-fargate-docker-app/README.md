# AWS ECS Fargate Docker Application

Deploy a Dockerized web application on Amazon ECS using AWS Fargate.

## Services
- Amazon ECS
- AWS Fargate
- Amazon ECR
- VPC
- IAM
- CloudWatch

## Steps
1. Build Docker image.
2. Push to Amazon ECR.
3. Create ECS Cluster.
4. Create Task Definition.
5. Deploy ECS Service using Fargate.
