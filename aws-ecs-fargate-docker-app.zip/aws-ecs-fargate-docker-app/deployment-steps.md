Build image, push to ECR, deploy to ECS Fargate.
